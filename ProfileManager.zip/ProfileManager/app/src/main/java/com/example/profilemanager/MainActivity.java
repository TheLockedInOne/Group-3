package com.example.profilemanager;

import static android.net.Uri.parse;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView mainImage;
    ActivityResultLauncher<Intent> selectImageLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button mapsButton = findViewById(R.id.button);

        mapsButton.setOnClickListener(this::OnOpenInGoogleMaps);

        mainImage = findViewById(R.id.imageView2);


        selectImageLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            int imageRes = data.getIntExtra("selectedImage", -1);
                            if (imageRes != -1) {
                                mainImage.setImageResource(imageRes);
                            }
                        }
                    }
                }

        );



        mainImage.setOnClickListener(v ->{
            Intent intent = new Intent(MainActivity.this, DataSelector.class);
            selectImageLauncher.launch(intent);
        });
    }
    public void OnOpenInGoogleMaps(View view){
        EditText teamAddress=(EditText) findViewById(R.id.editTextText5);
        Uri gmmIntentUri= Uri.parse("http://maps.google.co.in/maps?q=" + teamAddress.getText());
        Intent mapIntent= new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }
}