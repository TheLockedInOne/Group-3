package com.example.profilemanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DataSelector extends AppCompatActivity {
    ImageView img1,img2,img3,img4,img5,img6,img7,img8,img9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data_selector);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;


        });

        img1 = findViewById(R.id.imageView);
        img2 = findViewById(R.id.imageView3);
        img3 = findViewById(R.id.imageView4);
        img4 = findViewById(R.id.imageView5);
        img5 = findViewById(R.id.imageView6);
        img6 = findViewById(R.id.imageView7);
        img7 = findViewById(R.id.imageView8);
        img8 = findViewById(R.id.imageView9);
        img9 = findViewById(R.id.imageView10);

        img1.setOnClickListener(v -> returnImage(R.drawable.flag_ca));
        img2.setOnClickListener(v -> returnImage(R.drawable.flag_eg));
        img3.setOnClickListener(v -> returnImage(R.drawable.flag_fr));
        img4.setOnClickListener(v -> returnImage(R.drawable.flag_jp));
        img5.setOnClickListener(v -> returnImage(R.drawable.flag_kr));
        img6.setOnClickListener(v -> returnImage(R.drawable.flag_sp));
        img7.setOnClickListener(v -> returnImage(R.drawable.flag_tr));
        img8.setOnClickListener(v -> returnImage(R.drawable.flag_uk));
        img9.setOnClickListener(v -> returnImage(R.drawable.flag_us));
    }
    private void returnImage(int resId) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("selectedImage", resId);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

}