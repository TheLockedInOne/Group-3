package com.example.simplecalculator;

import net.objecthunter.exp4j.ExpressionBuilder;

public class Evaluate {

    public String evaluate(String expression) throws Exception {
        // Replace division symbol if used
        String replace = expression.replace('÷', '/');

        double result = new ExpressionBuilder(replace).build().evaluate();

        // Return as integer if it's a whole number, otherwise as decimal
        if (result == Math.floor(result)) {
            return Integer.toString((int) result);
        } else {
            return Double.toString(result);
        }
    }


}