package com.example.simplecalculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import net.objecthunter.exp4j.ExpressionBuilder;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btn1, btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0, btnclear, btnplus, btneq,btnmul,btndiv,btnsub,btndot;
    TextView text_display;

    // This is to evaluate the math expression


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btn0 = (Button) findViewById(R.id.btn0);
        btnplus = (Button) findViewById(R.id.btnplus);
        btneq = (Button) findViewById(R.id.btneq);
        btnclear = (Button) findViewById(R.id.btnclear);
        btnmul = (Button) findViewById(R.id.btnmul);
        btndiv = (Button) findViewById(R.id.btndiv);
        btnsub=(Button) findViewById(R.id.btnsub);
        btndot=(Button) findViewById(R.id.btndot);
        text_display = (TextView) findViewById(R.id.textview_input_display);

        setClickListeners();
    }

    private void setClickListeners() {
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn0.setOnClickListener(this);
        btndot.setOnClickListener(this);
        btnsub.setOnClickListener(this);
        btnplus.setOnClickListener(this);
        btndiv.setOnClickListener(this);
        btnmul.setOnClickListener(this);
        btneq.setOnClickListener(this);
        btnclear.setOnClickListener(this);
    }

    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.btn1) {
            addNumber("1");
        } else if (id == R.id.btn2) {
            addNumber("2");
        } else if (id == R.id.btn3) {
            addNumber("3");
        } else if (id == R.id.btn4) {
            addNumber("4");
        } else if (id == R.id.btn5) {
            addNumber("5");
        } else if (id == R.id.btn6) {
            addNumber("6");
        } else if (id == R.id.btn7) {
            addNumber("7");
        } else if (id == R.id.btn8) {
            addNumber("8");
        } else if (id == R.id.btn9) {
            addNumber("9");
        } else if (id == R.id.btn0) {
            addNumber("0");
        } else if (id == R.id.btnplus) {
            addNumber("+");
        } else if (id == R.id.btnsub) {
            addNumber("-");
        } else if (id == R.id.btnmul) {
            addNumber("*");
        } else if (id == R.id.btndiv) {
            addNumber("÷");
        } else if (id == R.id.btneq) {
            String result = null;
            try {
                result = evaluate(text_display.getText().toString());
                text_display.setText(result);
            } catch (Exception e) {
                text_display.setText("Error");
            }
        } else if (id == R.id.btnclear) {
            clear_display();
        }
        else if (id==R.id.btndot){
            addNumber(".");
        }

    }

    private String evaluate(String expression) throws Exception {
        String replace = expression.replace('÷', '/');
        double decimal = new ExpressionBuilder(replace).build().evaluate();
        if(decimal==Math.floor(decimal)) {
            int newdec=(int) decimal;
            return Integer.toString( newdec);
        }
        else {return Double.toString(decimal);}

    }

    @SuppressLint("SetTextI18n")
    private void addNumber(String number) {
        text_display.setText(text_display.getText() + number);
    }

    private void clear_display() {
        text_display.setText("");
    }
}
