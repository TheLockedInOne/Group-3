package com.example.simplecalculator;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MainActivityTest {
    @Test
    public void TwoPlusTwoShouldEqualFour() throws Exception {
        var calculator= new Evaluate();
        assertEquals("5",calculator.evaluate("2+2"));

    }




}
